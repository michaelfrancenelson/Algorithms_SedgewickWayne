import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

	private Percolation perc;
	private double[] thresholds;
	private int n;
//	private int t;
	
	public PercolationStats(int n, int trials){    // perform trials independent experiments on an n-by-n grid
		thresholds = new double[trials];
		if(n < 1 | trials < 1){throw new IllegalArgumentException();}
		this.n = n;
//		this.t = trials;
	}

	 // sample mean of percolation threshold
	public double mean(){return StdStats.mean(thresholds);}
	// sample standard deviation of percolation threshold
	public double stddev(){return StdStats.stddev(thresholds);}
	// low  endpoint of 95% confidence interval
	public double confidenceLo(){                  
		double 	z = stddev() / Math.sqrt(thresholds.length);
		return mean() - 1.96 * z;
	}
	// high endpoint of 95% confidence interval
	public double confidenceHi(){                  
		double 	z = stddev() / Math.sqrt(thresholds.length);
		return mean() - 1.96 * z;
	}

	public static void main(String[] args){
		
		int n = 200;
		int t = 100;

		if(args.length == 2){
			n = Integer.parseInt(args[0]);
			t = Integer.parseInt(args[1]);
		}

		PercolationStats ps = new PercolationStats(n, t);
		
		for(int trial = 0; trial < t; trial++){
			ps.perc = new Percolation(n);
			
			int nOpen = 0;
			int[] coords;
			int[] order = StdRandom.permutation(ps.n * ps.n);
			
			do{	coords = new int[] {(int) Math.floor(order[nOpen] / (double) n), order[nOpen] % n};
				ps.perc.open(coords[0] + 1, coords[1] + 1);
				nOpen++;
			} while(!ps.perc.percolates());
			
			ps.thresholds[trial] = ((double) nOpen) / ((double) (n * n));
		}

		StdOut.print(  "Mean   = " + ps.mean());
		StdOut.print("\nSD     = " + ps.stddev());
		StdOut.print("\n95% CI = [" + ps.confidenceLo() + ", " + ps.confidenceHi() + "]");
	}
}