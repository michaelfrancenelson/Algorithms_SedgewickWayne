import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

	private WeightedQuickUnionUF uf;

	/** grid of open and closed sites.  false = closed, true = open. */
	private Boolean[][] grid;

	public Percolation(int n){

		/* The last two elements are the 'dummy' nodes that are conneted to 
		 * all elements in the top and bottom rows, respectively.
		 * They are used as a shortcut to test for percolation. */
		uf = new WeightedQuickUnionUF(n * n + 2);

		for(int i = 0; i < n; i++) uf.union(i, n * n + 0);
		for(int i = n * n - n; i < n * n; i++) uf.union(i, n * n + 1);

		/* create n-by-n grid, with all sites blocked */
		grid = new Boolean[n][n];
		for(int i = 0; i < n; i++) for(int j = 0; j < n; j++) grid[i][j] = false;

	}

	/** Open site (row, col) if it is not open already 
	 * Assumes 2D coordinates start at (1, 1) */
	public void open(int row, int col){   
		int n = grid.length;

		if(row < 1 | col < 1 | row > n | col > n) throw new IllegalArgumentException();
		
		int index1     = (row - 1) * n + col - 1;
		int indexAbove = (row - 2) + col - 1;
		int indexBelow = (row - 0) + col - 1;
		int indexLeft  = (row - 1) + col - 2;
		int indexRight = (row - 1) + col - 0;

		/* If the cell is not already open. */
		if(! isOpen(row, col)){
			
			/* Open the cell */
			grid[row - 1][col - 1] = true;
			
			/* Check the von Neumann neighborhood for other open cells: */
			/* Upper neighbor: */
			if(row > 1) if(isOpen(row - 1, col)){
				uf.union(index1, indexAbove);}
			/* Lower neighbor: */
			if(row < n) if(isOpen(row + 1, col)) {
				uf.union(index1, indexBelow);}
			/* Left neighbor: */
			if(col > 1) if(isOpen(row, col - 1)){
				uf.union(index1, indexLeft);}
			/* Right neighbor: */
			if(col < n) if(isOpen(row, col + 1)) {
				uf.union(index1, indexRight);}
		}
	}

	/** is site (row, col) open? */
	public boolean isOpen(int row, int col){
		int n = grid.length;
		if(row < 1 | col < 1 | row > n | col > n) throw new IllegalArgumentException();
		return grid[row - 1][col - 1];
	}  

	/** is site (row, col) full? */
	public boolean isFull(int row, int col){
		int n = grid.length;
		if(row < 1 | col < 1 | row > n | col > n) throw new IllegalArgumentException();
		return !grid[row - 1][col - 1];
	}

	/**  number of open sites */
	public int numberOfOpenSites(){
		int n = grid.length;
		int count = 0;
		for(int i = 0; i < n; i++) for(int j = 0; j < n; j++) 
			if(grid[i][j] == true) count++;
		return count;
	}      
	
	/** does the system percolate? */
	public boolean percolates(){      
		int n = grid.length;
		return uf.connected(n * n, n * n + 1);
	}

	
	public static void main(String[] args){
//		int n = 10;
//		Percolation perc = new Percolation(n);
//		int count = perc.simulate();
//		StdOut.print("/nSystem percolated after " + count + " cells were opened.");
	}
	
}